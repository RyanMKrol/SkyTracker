DROP TABLE EMA_BGO;

CREATE TABLE EMA_BGO(

TripID int NOT NULL AUTO_INCREMENT,
SourcePort varchar(255) NOT NULL,
DestPort varchar(255) NOT NULL,
DepartDate DATE NOT NULL,
ReturnDate DATE NOT NULL,
Price int NOT NULL,
PRIMARY KEY(TripID),
CONSTRAINT uc_date_pair UNIQUE (DepartDate, ReturnDate)
);

INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-04-20', '2017-04-22', 903);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-04-21', '2017-04-24', 944);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-04-21', '2017-04-28', 1102);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-04-26', '2017-05-03', 608);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-04-29', '2017-05-06', 859);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-04', '2017-05-05', 729);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-05', '2017-05-07', 871);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-05', '2017-05-08', 724);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-02', '2017-05-09', 844);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-10', '2017-05-11', 882);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-11', '2017-05-11', 943);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-12', '2017-05-14', 419);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-11', '2017-05-18', 720);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-12', '2017-05-19', 296);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-19', '2017-05-22', 407);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-22', '2017-05-24', 488);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-23', '2017-05-26', 770);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-25', '2017-05-27', 389);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-27', '2017-05-29', 779);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-05-29', '2017-06-01', 772);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-06-10', '2017-06-18', 467);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-06-16', '2017-06-19', 403);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-06-19', '2017-06-23', 344);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-06-23', '2017-06-25', 488);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-06-19', '2017-06-26', 326);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-06-12', '2017-07-07', 366);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-06-28', '2017-07-12', 443);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-06-30', '2017-07-14', 397);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-07-10', '2017-07-14', 353);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-07-13', '2017-07-16', 405);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-07-14', '2017-07-16', 463);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-07-15', '2017-07-16', 810);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-07-08', '2017-07-22', 465);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-07-22', '2017-07-29', 481);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-08-04', '2017-08-07', 356);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-08-04', '2017-08-08', 368);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-08-06', '2017-08-13', 392);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-08-10', '2017-08-13', 339);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-08-17', '2017-08-21', 579);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-09-01', '2017-09-04', 811);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-09-01', '2017-09-08', 1093);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-09-15', '2017-09-18', 1353);
INSERT INTO EMA_BGO (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','BGO','2017-09-24', '2017-09-30', 859);
