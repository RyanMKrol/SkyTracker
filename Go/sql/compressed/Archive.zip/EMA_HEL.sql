DROP TABLE EMA_HEL;

CREATE TABLE EMA_HEL(

TripID int NOT NULL AUTO_INCREMENT,
SourcePort varchar(255) NOT NULL,
DestPort varchar(255) NOT NULL,
DepartDate DATE NOT NULL,
ReturnDate DATE NOT NULL,
Price int NOT NULL,
PRIMARY KEY(TripID),
CONSTRAINT uc_date_pair UNIQUE (DepartDate, ReturnDate)
);

INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-12', '2017-04-13', 1715);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-17', '2017-04-20', 1330);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-19', '2017-04-21', 885);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-20', '2017-04-21', 729);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-19', '2017-04-22', 756);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-20', '2017-04-22', 580);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-21', '2017-04-23', 1492);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-22', '2017-04-23', 1150);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-20', '2017-04-25', 508);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-21', '2017-04-26', 500);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-22', '2017-04-26', 1265);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-23', '2017-04-26', 1159);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-25', '2017-04-27', 801);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-25', '2017-04-29', 561);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-27', '2017-04-30', 782);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-28', '2017-04-30', 1183);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-28', '2017-05-01', 544);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-27', '2017-05-02', 874);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-16', '2017-05-09', 665);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-17', '2017-05-10', 1229);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-04-18', '2017-05-11', 914);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-02', '2017-05-03', 513);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-02', '2017-05-04', 689);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-03', '2017-05-04', 576);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-01', '2017-05-05', 549);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-04', '2017-05-07', 425);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-05', '2017-05-07', 1495);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-07', '2017-05-11', 534);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-08', '2017-05-11', 589);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-09', '2017-05-11', 542);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-05', '2017-05-12', 495);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-12', '2017-05-13', 473);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-12', '2017-05-14', 549);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-03', '2017-05-15', 413);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-13', '2017-05-15', 1072);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-12', '2017-05-17', 320);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-12', '2017-05-18', 427);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-14', '2017-05-18', 549);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-16', '2017-05-18', 599);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-16', '2017-05-19', 536);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-07', '2017-05-20', 413);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-12', '2017-05-20', 347);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-13', '2017-05-20', 1015);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-19', '2017-05-22', 489);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-22', '2017-05-25', 482);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-14', '2017-05-27', 1266);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-25', '2017-05-28', 649);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-26', '2017-05-28', 550);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-25', '2017-05-29', 474);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-27', '2017-06-01', 1461);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-28', '2017-06-04', 593);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-05', '2017-06-05', 1396);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-05-23', '2017-06-13', 460);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-02', '2017-06-04', 549);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-02', '2017-06-05', 550);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-04', '2017-06-08', 524);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-05', '2017-06-09', 540);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-07', '2017-06-11', 451);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-08', '2017-06-11', 510);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-12', '2017-06-14', 546);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-13', '2017-06-14', 537);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-14', '2017-06-14', 973);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-14', '2017-06-15', 496);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-13', '2017-06-16', 540);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-15', '2017-06-18', 538);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-16', '2017-06-18', 676);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-16', '2017-06-19', 792);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-17', '2017-06-20', 1028);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-18', '2017-06-20', 550);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-05', '2017-06-21', 457);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-17', '2017-06-21', 1024);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-17', '2017-06-22', 1108);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-21', '2017-06-22', 498);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-21', '2017-06-23', 597);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-15', '2017-06-25', 542);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-16', '2017-06-25', 749);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-23', '2017-06-26', 509);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-24', '2017-06-28', 1013);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-20', '2017-06-30', 473);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-06-24', '2017-07-03', 1013);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-03', '2017-07-07', 406);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-06', '2017-07-09', 463);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-06', '2017-07-10', 398);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-07', '2017-07-10', 555);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-07', '2017-07-11', 530);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-10', '2017-07-14', 703);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-17', '2017-07-24', 983);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-20', '2017-07-25', 386);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-23', '2017-07-28', 551);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-28', '2017-07-30', 519);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-28', '2017-07-31', 565);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-07-31', '2017-08-04', 490);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-11', '2017-08-13', 414);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-08', '2017-08-14', 385);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-09', '2017-08-14', 379);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-10', '2017-08-14', 1464);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-03', '2017-08-17', 1491);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-16', '2017-08-17', 393);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-17', '2017-08-17', 1455);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-08', '2017-08-18', 335);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-14', '2017-08-18', 409);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-27', '2017-08-30', 1084);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-18', '2017-09-01', 559);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-08-27', '2017-09-02', 1148);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-09-04', '2017-09-09', 327);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-09-11', '2017-09-15', 374);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-09-21', '2017-09-24', 322);
INSERT INTO EMA_HEL (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','HEL','2017-09-27', '2017-10-04', 327);
