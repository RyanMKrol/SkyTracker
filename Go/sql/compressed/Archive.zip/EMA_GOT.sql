DROP TABLE EMA_GOT;

CREATE TABLE EMA_GOT(

TripID int NOT NULL AUTO_INCREMENT,
SourcePort varchar(255) NOT NULL,
DestPort varchar(255) NOT NULL,
DepartDate DATE NOT NULL,
ReturnDate DATE NOT NULL,
Price int NOT NULL,
PRIMARY KEY(TripID),
CONSTRAINT uc_date_pair UNIQUE (DepartDate, ReturnDate)
);

INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-19', '2017-04-20', 423);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-17', '2017-04-21', 1380);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-19', '2017-04-21', 460);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-20', '2017-04-21', 477);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-21', '2017-04-23', 609);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-22', '2017-04-26', 918);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-24', '2017-04-26', 420);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-24', '2017-04-27', 495);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-25', '2017-04-27', 494);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-24', '2017-04-28', 495);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-27', '2017-04-28', 917);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-28', '2017-04-30', 428);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-29', '2017-04-30', 897);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-28', '2017-05-01', 411);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-29', '2017-05-01', 878);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-30', '2017-05-01', 603);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-28', '2017-05-02', 394);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-29', '2017-05-02', 885);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-29', '2017-05-03', 863);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-04-24', '2017-05-26', 346);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-01', '2017-05-03', 392);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-02', '2017-05-04', 320);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-03', '2017-05-04', 349);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-01', '2017-05-05', 371);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-02', '2017-05-05', 376);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-08', '2017-05-09', 370);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-09', '2017-05-09', 928);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-08', '2017-05-11', 341);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-07', '2017-05-12', 352);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-08', '2017-05-12', 354);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-09', '2017-05-12', 352);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-10', '2017-05-12', 320);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-08', '2017-05-13', 449);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-09', '2017-05-13', 376);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-10', '2017-05-14', 352);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-12', '2017-05-14', 373);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-13', '2017-05-14', 874);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-10', '2017-05-15', 337);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-12', '2017-05-15', 339);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-14', '2017-05-17', 320);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-19', '2017-05-22', 328);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-19', '2017-05-23', 317);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-19', '2017-05-24', 340);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-20', '2017-05-24', 898);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-23', '2017-05-25', 689);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-24', '2017-05-25', 359);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-26', '2017-05-29', 875);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-25', '2017-05-30', 290);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-30', '2017-06-01', 765);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-30', '2017-06-02', 368);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-05-25', '2017-06-08', 359);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-01', '2017-06-04', 642);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-02', '2017-06-04', 327);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-02', '2017-06-07', 328);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-01', '2017-06-09', 310);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-08', '2017-06-09', 363);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-15', '2017-06-19', 2873);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-18', '2017-06-21', 331);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-20', '2017-06-22', 344);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-24', '2017-06-25', 927);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-25', '2017-06-25', 1340);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-26', '2017-06-29', 356);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-06-28', '2017-07-05', 283);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-07-14', '2017-07-19', 510);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-07-15', '2017-07-20', 905);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-07-15', '2017-07-22', 963);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-07-22', '2017-07-27', 837);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-07-14', '2017-07-30', 536);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-07-17', '2017-08-03', 326);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-05', '2017-08-11', 1732);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-09', '2017-08-13', 293);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-07', '2017-08-14', 321);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-08', '2017-08-14', 301);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-09', '2017-08-14', 300);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-13', '2017-08-27', 1692);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-23', '2017-08-27', 648);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-14', '2017-08-28', 612);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-27', '2017-08-29', 824);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-16', '2017-08-30', 556);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-17', '2017-08-31', 621);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-21', '2017-09-01', 300);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-30', '2017-09-01', 652);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-18', '2017-09-03', 610);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-08-20', '2017-09-03', 1704);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-09-12', '2017-09-14', 337);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-09-14', '2017-09-15', 309);
INSERT INTO EMA_GOT (SourcePort, DestPort, DepartDate, ReturnDate, Price) VALUES ('EMA','GOT','2017-09-13', '2017-09-20', 2161);
