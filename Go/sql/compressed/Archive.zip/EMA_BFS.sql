DROP TABLE EMA_BFS;

CREATE TABLE EMA_BFS(

TripID int NOT NULL AUTO_INCREMENT,
SourcePort varchar(255) NOT NULL,
DestPort varchar(255) NOT NULL,
DepartDate DATE NOT NULL,
ReturnDate DATE NOT NULL,
Price int NOT NULL,
PRIMARY KEY(TripID),
CONSTRAINT uc_date_pair UNIQUE (DepartDate, ReturnDate)
);

